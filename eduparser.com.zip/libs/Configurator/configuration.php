<?php
/******* BACKWARDS COMPATABILITY *******/
require_once __DIR__."/Configurator.php";
?>