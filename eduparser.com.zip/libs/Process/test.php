<?php
require_once "Process.php";

print Process::fastCheck("sftp")."\n";

?>
